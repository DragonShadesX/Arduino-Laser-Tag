
class Radio
{
  public:
    char * name;
    char * server;
    char * url;
    int    port;
};

